#include "pc.h"

int main( int argc, const char* argv[] ) {

    int num_ops; /*So the compiler does not optimize away our code */
    unsigned int seed  = 0;
    init();

    auto start = std::chrono::system_clock::now();

    for (int i = 0; i < NUM_ITER; i++) {
        produce(&seed);
        num_ops += consume();
    }
    
    auto end = std::chrono::system_clock::now();

    auto elapsed =
        std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
        std::cout << elapsed.count() << " operations " << num_ops << std::endl;;

    return 0;
}